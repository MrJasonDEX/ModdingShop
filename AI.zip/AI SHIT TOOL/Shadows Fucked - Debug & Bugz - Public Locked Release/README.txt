SHADOWS FUCKED - DEBUG & BUGZ
LOCKED RELEASE

Run: Shadows Fucked - Debug & Bugz.exe
Keep the matching .exe.config file beside it.

This release contains only the protected executable and its runtime configuration.
It does not contain source code, debug symbols, or the private obfuscation map.

Protection applied:
- Public and private symbols renamed
- Unicode symbol names enabled
- Embedded strings hidden
- Option catalogs encrypted inside the executable
- Debug symbols removed
- IL disassembly suppression marker added
- Free-form Raw Commands interface removed
- Exact option payloads removed from visible activity logs

The curated Infections page includes all supplied Kozy menu entries:
- 13 locked dvar infection presets
- One-shot session UAV
- Start/stop 1.5-second session UAV refresh loop

No client-side .NET application is impossible to reverse-engineer, but this build
is substantially harder to inspect than the development build.

SHA-256:
22B6ACF248F1916E3294A4813E0E9F6CFFDB564A2E5381E268BB027F2FFDE55B
